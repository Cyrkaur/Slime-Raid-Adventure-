---
name: slime-adventure
description: >
  Project-local skill for Slime Adventure / Raid of the Slimes conventions.
  Prefer this when working inside this repo.
metadata:
  short-description: "Local slime game conventions"
---

# Local project skill

See user skill `slime-adventure` for full conventions.

**Quick rules**

1. Shell order: hero banner (+ currencies) → Wilds Patrol → Haven → tabs  
2. Summon modal: pinned Continue + Esc + backdrop  
3. Stage tiles: `assets/stages/`, tile width 720  
4. Canonical docs: `GAMEPLAN.md`  
5. Remote: `Cyrkaur/Slime-Raid-Adventure-`  

After features: update GAMEPLAN, then `/sync-project`.
